class Comment < ApplicationRecord
  belongs_to :task
end
