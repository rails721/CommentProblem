class User < ApplicationRecord
  has_many :tasks
  has_many :comments
  accepts_nested_attributes_for :comments, reject_if: :all_blank, allow_destroy: true
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable

  # Remove email validation
  validates :username, presence: true, uniqueness: true
  # Optionally, remove email validation and uniqueness constraint
  def email_required?
    false
  end

  def email_changed?
    false
  end
end
