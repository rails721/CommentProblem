class TasksController < ApplicationController
    before_action :authenticate_user!

    def index
      @tasks = Task.all # Fetch all tasks for the index view
    end
  
    def new
      @task = Task.new
      @task.comments.build # This creates an empty comment associated with the task
    end   
  
    def create
      @task = current_user.tasks.build(task_params)
  
      if @task.save
        redirect_to @task, notice: "Task created successfully."
      else
        render :new
      end
    end
  
    def show
      @task = Task.find(params[:id])
      @comments = @task.comments # Fetch comments associated with the task
    end

    def create_comment
      @task = Task.find(params[:task_id]) # Find the task by ID
      @comment = @task.comments.build(comment_params) # Build a new comment associated with the task
      if @comment.save
        redirect_to @task, notice: 'Comment was successfully created.'
      else
        render :show
      end
    end
  
    def edit
      @task = Task.find(params[:id])  # Find the task by ID for editing
    end
  
    def update
      @task = Task.find(params[:id])  # Find the task by ID
      if @task.update(task_params)
        redirect_to tasks_path, notice: 'Task was successfully updated.'
      else
        render :edit
      end
    end
    
    private
  
    def task_params
      params.require(:task).permit(:name, :status, :task_type, comments_attributes: [:id, :content, :_destroy])
    end

    def comment_params
      params.require(:comment).permit(:content) # Permit the content attribute for comments
    end
  end
  