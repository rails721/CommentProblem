class CommentsController < ApplicationController
    def create
      @task = Task.find(params[:task_id]) # Find the task by ID
      @comment = @task.comments.build(comment_params) # Build a new comment associated with the task
      if @comment.save
        redirect_to @task, notice: 'Comment was successfully created.'
      else
        render 'tasks/show' # Render the task's show view
      end
    end
  
    def destroy
      @comment = Comment.find(params[:id]) # Find the comment by ID
      @comment.destroy
      redirect_to task_path(@comment.task), notice: 'Comment was successfully deleted.'
    end
  
    private
  
    def comment_params
      params.require(:comment).permit(:content) # Permit the content attribute for comments
    end
  end

  